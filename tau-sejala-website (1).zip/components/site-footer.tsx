import Link from "next/link"
import { Button } from "@/components/ui/button"
import { LucideFacebook, LucideInstagram, LucideLinkedin, LucideMail, LucidePhone } from "lucide-react"

export default function SiteFooter() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold">Tau Sejala Enterprise</h3>
            <p className="text-gray-300">The Lion of Sustainable Innovation</p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-white hover:text-green-400 hover:bg-transparent">
                <LucideFacebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:text-green-400 hover:bg-transparent">
                <LucideInstagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:text-green-400 hover:bg-transparent">
                <LucideLinkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-green-400">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/wastelink" className="text-gray-300 hover:text-green-400">
                  WasteLink
                </Link>
              </li>
              <li>
                <Link href="/dwp" className="text-gray-300 hover:text-green-400">
                  Domestic Waste Project
                </Link>
              </li>
              <li>
                <Link href="/shop" className="text-gray-300 hover:text-green-400">
                  Shop
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-300 hover:text-green-400">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/wastelink/booking" className="text-gray-300 hover:text-green-400">
                  Book a Pickup
                </Link>
              </li>
              <li>
                <Link href="/dwp/register" className="text-gray-300 hover:text-green-400">
                  Join DWP Training
                </Link>
              </li>
              <li>
                <Link href="/shop" className="text-gray-300 hover:text-green-400">
                  Shop Eco-Products
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-gray-300">
                <LucideMail className="h-4 w-4 text-green-400" />
                <a href="mailto:info@tausejala.co.za" className="hover:text-green-400">
                  info@tausejala.co.za
                </a>
              </li>
              <li className="flex items-center gap-2 text-gray-300">
                <LucidePhone className="h-4 w-4 text-green-400" />
                <a href="tel:+27123456789" className="hover:text-green-400">
                  +27 12 345 6789
                </a>
              </li>
            </ul>
            <Button asChild className="mt-4 bg-green-600 hover:bg-green-700">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400 text-sm">
          <p>© 2025 Tau Sejala Enterprise. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <Link href="/privacy-policy" className="hover:text-green-400">
              Privacy Policy
            </Link>
            <Link href="/terms-conditions" className="hover:text-green-400">
              Terms & Conditions
            </Link>
          </div>
          <p className="mt-2">
            Website powered by{" "}
            <a
              href="https://www.ramscount.co.za"
              target="_blank"
              rel="noopener noreferrer"
              className="text-green-400 hover:underline"
            >
              www.ramscount.co.za
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}

