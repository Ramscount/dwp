import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { LucideSearch, LucideShoppingCart } from "lucide-react"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const products = [
  {
    id: 1,
    name: "Recycled Paper Notebook",
    category: "paper",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Eco-friendly notebook made from 100% recycled paper",
  },
  {
    id: 2,
    name: "Upcycled Tire Planter",
    category: "home",
    price: 249.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Stylish planter made from upcycled tires",
  },
  {
    id: 3,
    name: "Reusable Shopping Bag",
    category: "bags",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Durable shopping bag made from recycled plastic bottles",
  },
  {
    id: 4,
    name: "Bamboo Cutlery Set",
    category: "kitchen",
    price: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Portable bamboo cutlery set for eco-conscious dining",
  },
  {
    id: 5,
    name: "Recycled Glass Vase",
    category: "home",
    price: 179.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Beautiful vase crafted from recycled glass",
  },
  {
    id: 6,
    name: "Composting Kit",
    category: "garden",
    price: 349.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Complete kit for home composting of organic waste",
  },
  {
    id: 7,
    name: "Upcycled Bottle Lamp",
    category: "home",
    price: 299.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Unique lamp made from upcycled glass bottles",
  },
  {
    id: 8,
    name: "Recycled Paper Gift Cards",
    category: "paper",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    description: "Set of 5 greeting cards made from recycled paper",
  },
]

export default function ShopPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-3xl font-bold text-center mb-8">Eco-Friendly Products</h1>

      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="relative w-full md:w-96">
          <Input placeholder="Search products..." className="pl-10" />
          <LucideSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>

        <Link href="/shop/cart">
          <Button variant="outline" className="flex items-center gap-2">
            <LucideShoppingCart className="h-4 w-4" />
            <span>Cart (0)</span>
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="grid grid-cols-2 md:grid-cols-6 w-full">
          <TabsTrigger value="all">All Products</TabsTrigger>
          <TabsTrigger value="home">Home Decor</TabsTrigger>
          <TabsTrigger value="bags">Bags & Bottles</TabsTrigger>
          <TabsTrigger value="paper">Paper Products</TabsTrigger>
          <TabsTrigger value="kitchen">Kitchen</TabsTrigger>
          <TabsTrigger value="garden">Garden</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </TabsContent>

        {["home", "bags", "paper", "kitchen", "garden"].map((category) => (
          <TabsContent key={category} value={category} className="mt-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {products
                .filter((product) => product.category === category)
                .map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

function ProductCard({ product }: { product: (typeof products)[0] }) {
  return (
    <Card className="overflow-hidden border-green-100 shadow-md hover:shadow-lg transition-shadow">
      <div className="relative h-48 w-full">
        <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
        <Badge className="absolute top-2 right-2 bg-green-600">R{product.price.toFixed(2)}</Badge>
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{product.name}</CardTitle>
        <CardDescription className="line-clamp-2">{product.description}</CardDescription>
      </CardHeader>
      <CardFooter>
        <Button className="w-full bg-green-600 hover:bg-green-700" asChild>
          <Link href={`/shop/product/${product.id}`}>View Product</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

