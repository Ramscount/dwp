import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LucideCalendarCheck, LucideTruck, LucideRecycle } from "lucide-react"
import Image from "next/image"

export default function WasteLinkPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="WasteLink waste management"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center items-start text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">WasteLink</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl">
            Smart waste management platform for efficient pickup and disposal solutions
          </p>
          <Button size="lg" className="bg-green-600 hover:bg-green-700" asChild>
            <Link href="/wastelink/booking">Book a Pickup</Link>
          </Button>
        </div>
      </section>

      {/* Key Benefits */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Key Benefits</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideCalendarCheck className="h-6 w-6 text-green-600" />
                  Easy Online Booking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Schedule waste pickups at your convenience with our simple online booking system. Choose the date and
                  time that works best for you.
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideTruck className="h-6 w-6 text-green-600" />
                  Real-time Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Track your waste collectors in real-time for better service transparency and know exactly when they'll
                  arrive at your location.
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideRecycle className="h-6 w-6 text-green-600" />
                  Sustainable Disposal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Rest assured that your waste is properly sorted, recycled, and discarded at certified centers
                  following eco-friendly practices.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-green-600 text-white flex items-center justify-center text-2xl font-bold mb-4">
                1
              </div>
              <h3 className="text-xl font-semibold mb-2">Register & Book</h3>
              <p>Sign up and schedule a pickup for your waste through our easy-to-use platform.</p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-green-600 text-white flex items-center justify-center text-2xl font-bold mb-4">
                2
              </div>
              <h3 className="text-xl font-semibold mb-2">We Collect</h3>
              <p>Our trained collectors arrive at the scheduled time to pick up your waste.</p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-green-600 text-white flex items-center justify-center text-2xl font-bold mb-4">
                3
              </div>
              <h3 className="text-xl font-semibold mb-2">Responsible Disposal</h3>
              <p>Your waste is transported to appropriate recycling centers or eco-friendly disposal facilities.</p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700" asChild>
              <Link href="/wastelink/booking">Book a Waste Pickup</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

