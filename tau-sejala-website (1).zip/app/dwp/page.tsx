import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LucideGraduationCap, LucideBriefcase, CloudLightningIcon as LucideCertificate } from "lucide-react"
import Image from "next/image"

export default function DWPPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[400px] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <Image
          src="/placeholder.svg?height=400&width=1200"
          alt="Domestic Waste Project training"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center items-start text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Domestic Waste Project (DWP)</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl">
            Training and equipping unemployed individuals with waste management skills
          </p>
          <Button size="lg" className="bg-green-600 hover:bg-green-700" asChild>
            <Link href="/dwp/register">Join Our Training Program</Link>
          </Button>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Empowering Through Skills Development</h2>
            <p className="text-lg mb-8">
              The Domestic Waste Project (DWP) initiative empowers unemployed individuals, waste pickers, and
              professionals by equipping them with waste management skills. Our goal is to reduce unemployment, promote
              sustainability, and support waste entrepreneurs.
            </p>
          </div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What We Offer</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideGraduationCap className="h-6 w-6 text-green-600" />
                  Training Programs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Free & subsidized training programs on waste sorting, recycling, and upcycling. Our comprehensive
                  curriculum covers all aspects of sustainable waste management.
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideBriefcase className="h-6 w-6 text-green-600" />
                  Business Development
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Business development support to help trained individuals start waste-related businesses. We provide
                  mentorship, resources, and networking opportunities.
                </p>
              </CardContent>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideCertificate className="h-6 w-6 text-green-600" />
                  Certification
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  Certification upon completion of the training program, improving employability and credibility in the
                  waste management industry.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Success Stories</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                name: "Thabo Mokoena",
                role: "Recycling Entrepreneur",
                image: "/placeholder.svg?height=300&width=300",
                quote:
                  "The DWP training gave me the skills and confidence to start my own recycling business. I now employ five people from my community.",
              },
              {
                name: "Lerato Ndlovu",
                role: "Waste Management Specialist",
                image: "/placeholder.svg?height=300&width=300",
                quote:
                  "After completing the DWP program, I secured a job at a waste management company. The certification made all the difference in my job search.",
              },
            ].map((story, index) => (
              <Card key={index} className="border-green-100 shadow-md">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row gap-6 items-center">
                    <div className="relative w-24 h-24 rounded-full overflow-hidden">
                      <Image src={story.image || "/placeholder.svg"} alt={story.name} fill className="object-cover" />
                    </div>
                    <div>
                      <blockquote className="text-lg italic mb-4">"{story.quote}"</blockquote>
                      <div className="font-semibold">{story.name}</div>
                      <div className="text-sm text-gray-500">{story.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700" asChild>
              <Link href="/dwp/register">Join Our Training Program</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

