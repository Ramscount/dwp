import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { LucideSearch, LucideCalendar, LucideUser } from "lucide-react"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"

const blogPosts = [
  {
    id: 1,
    title: "How to Reduce Household Waste in 5 Steps",
    excerpt:
      "Simple strategies to minimize your environmental footprint at home. Learn practical tips that anyone can implement to reduce waste generation.",
    image: "/placeholder.svg?height=400&width=800",
    category: "Waste Reduction",
    author: "Nomsa Dlamini",
    date: "March 15, 2025",
  },
  {
    id: 2,
    title: "Meet Our Waste Pickers Turned Entrepreneurs",
    excerpt:
      "Success stories from our DWP program participants who have transformed their lives through waste management skills and entrepreneurship.",
    image: "/placeholder.svg?height=400&width=800",
    category: "Success Stories",
    author: "Sipho Mabaso",
    date: "March 10, 2025",
  },
  {
    id: 3,
    title: "The Impact of Upcycling on the Environment",
    excerpt:
      "How creative reuse is changing the waste management landscape and contributing to a more sustainable future for our planet.",
    image: "/placeholder.svg?height=400&width=800",
    category: "Upcycling",
    author: "Thandi Nkosi",
    date: "March 5, 2025",
  },
  {
    id: 4,
    title: "Waste Management Innovations in South Africa",
    excerpt:
      "Exploring the latest technologies and approaches that are revolutionizing waste management practices across South Africa.",
    image: "/placeholder.svg?height=400&width=800",
    category: "Innovation",
    author: "Bongani Khumalo",
    date: "February 28, 2025",
  },
  {
    id: 5,
    title: "Community Cleanup: Making a Difference Together",
    excerpt:
      "How community-led initiatives are transforming neighborhoods and creating cleaner, healthier environments for everyone.",
    image: "/placeholder.svg?height=400&width=800",
    category: "Community",
    author: "Lerato Molefe",
    date: "February 20, 2025",
  },
  {
    id: 6,
    title: "The Business of Waste: Opportunities in Recycling",
    excerpt:
      "Exploring entrepreneurial opportunities in the waste management and recycling sectors for aspiring business owners.",
    image: "/placeholder.svg?height=400&width=800",
    category: "Business",
    author: "Mandla Zulu",
    date: "February 15, 2025",
  },
]

export default function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-3xl font-bold text-center mb-8">Sustainability & Waste Management Blog</h1>

      <div className="relative w-full max-w-md mx-auto mb-12">
        <Input placeholder="Search articles..." className="pl-10" />
        <LucideSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map((post) => (
          <Card key={post.id} className="overflow-hidden border-green-100 shadow-md hover:shadow-lg transition-shadow">
            <div className="relative h-48 w-full">
              <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              <Badge className="absolute top-2 right-2 bg-green-600">{post.category}</Badge>
            </div>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">{post.title}</CardTitle>
              <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
                <div className="flex items-center gap-1">
                  <LucideUser className="h-3 w-3" />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center gap-1">
                  <LucideCalendar className="h-3 w-3" />
                  <span>{post.date}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription className="line-clamp-3">{post.excerpt}</CardDescription>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link href={`/blog/${post.id}`}>Read More</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

