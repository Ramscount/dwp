import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LucideRecycle, LucideUsers, LucideShoppingBag, LucideArrowRight } from "lucide-react"
import Image from "next/image"
import LiveChat from "@/components/live-chat"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[600px] w-full">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <Image
          src="/placeholder.svg?height=600&width=1200"
          alt="Waste management initiative"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 container mx-auto px-4 h-full flex flex-col justify-center items-start text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Innovating Waste Management for a Sustainable Future</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl">
            Tau Sejala Enterprise - The Lion of Sustainable Innovation
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild className="bg-green-600 hover:bg-green-700">
              <Link href="/wastelink">Book a Service</Link>
            </Button>
            <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10" asChild>
              <Link href="/shop">Shop Eco-Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">About Tau Sejala Enterprise</h2>
          <p className="text-lg text-center max-w-4xl mx-auto mb-12">
            Tau Sejala Enterprise is dedicated to making waste management accessible and sustainable through technology
            and skills development. We've launched two flagship initiatives to drive our mission forward.
          </p>

          <div className="grid md:grid-cols-2 gap-8 mt-12">
            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideRecycle className="h-6 w-6 text-green-600" />
                  WasteLink App
                </CardTitle>
                <CardDescription>
                  A digital waste management platform for efficient pickup and disposal solutions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p>
                  Our innovative app connects residents and businesses with reliable waste collection services, ensuring
                  proper disposal and recycling of waste materials.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/wastelink">Learn More</Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LucideUsers className="h-6 w-6 text-green-600" />
                  Domestic Waste Project (DWP)
                </CardTitle>
                <CardDescription>
                  Training and equipping unemployed individuals with waste management skills
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p>
                  Our DWP program empowers waste pickers and professionals with the skills needed to promote
                  sustainability and economic empowerment.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/dwp">Learn More</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="text-center">Book a Pickup</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <LucideRecycle className="h-16 w-16 text-green-600" />
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button asChild>
                  <Link href="/wastelink/booking" className="flex items-center gap-2">
                    Book Now <LucideArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="text-center">Join DWP Training</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <LucideUsers className="h-16 w-16 text-green-600" />
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button asChild>
                  <Link href="/dwp/register" className="flex items-center gap-2">
                    Register <LucideArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="border-green-100 shadow-md">
              <CardHeader>
                <CardTitle className="text-center">Shop Eco-Products</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <LucideShoppingBag className="h-16 w-16 text-green-600" />
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button asChild>
                  <Link href="/shop" className="flex items-center gap-2">
                    Shop Now <LucideArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Blog Preview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold">Latest Articles</h2>
            <Button variant="outline" asChild>
              <Link href="/blog">View All</Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "How to Reduce Household Waste in 5 Steps",
                excerpt: "Simple strategies to minimize your environmental footprint at home.",
                image: "/placeholder.svg?height=200&width=400",
              },
              {
                title: "Meet Our Waste Pickers Turned Entrepreneurs",
                excerpt: "Success stories from our DWP program participants.",
                image: "/placeholder.svg?height=200&width=400",
              },
              {
                title: "The Impact of Upcycling on the Environment",
                excerpt: "How creative reuse is changing the waste management landscape.",
                image: "/placeholder.svg?height=200&width=400",
              },
            ].map((post, index) => (
              <Card key={index} className="border-green-100 shadow-md overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{post.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="w-full" asChild>
                    <Link href={`/blog/${index + 1}`}>Read More</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Live Chat */}
      <LiveChat />
    </div>
  )
}

